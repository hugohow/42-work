#!/bin/sh

set -ef

"${abs_srcdir}/test-airolib-sqlite.sh" "${top_builddir}/src"

exit 0

