Airoscript options
===================
This menu provides with a set of airoscript-ng configuration options, wich can be changed after startup.

- Change / reset interface
- Change interface MAC
- Enable monitor mode
- Change dump path 
- Try to configure network
